
-- Create Patient table
CREATE TABLE Patient (
 PatientID INT PRIMARY KEY,
 FirstName VARCHAR(50),
 LastName VARCHAR(50),
 DateOfBirth DATE,
 Gender CHAR(1),
 ContactNumber VARCHAR(15),
 Address VARCHAR(100)
);
-- Create Doctor table
CREATE TABLE Doctor (
 DoctorID INT PRIMARY KEY,
 FirstName VARCHAR(50),
 LastName VARCHAR(50),
 Specialty VARCHAR(50),
 ContactNumber VARCHAR(15),
 Email VARCHAR(100)
);
-- Create Appointment table
CREATE TABLE Appointment (
 AppointmentID INT PRIMARY KEY,
 PatientID INT,
 DoctorID INT,
 AppointmentDate DATE,
 AppointmentTime TIME,
 Status VARCHAR(20),
 FOREIGN KEY (PatientID) REFERENCES Patient(PatientID),
 FOREIGN KEY (DoctorID) REFERENCES Doctor(DoctorID)
);
-- Create Department table
CREATE TABLE Department (
 DepartmentID INT PRIMARY KEY,
 DepartmentName VARCHAR(50),
 Description VARCHAR(100)
);
-- Create MedicalRecord table
CREATE TABLE MedicalRecord (
 RecordID INT PRIMARY KEY,
 PatientID INT,
 DoctorID INT,
 Diagnosis VARCHAR(200),
 Prescription VARCHAR(200),
 DateRecorded DATE,
 FOREIGN KEY (PatientID) REFERENCES Patient(PatientID),
 FOREIGN KEY (DoctorID) REFERENCES Doctor(DoctorID)
);

-- Insert records into the Patient table
INSERT INTO Patient (PatientID, FirstName, LastName, DateOfBirth, Gender, ContactNumber, 
Address)
VALUES
 (1, 'John', 'Doe', '1980-05-15', 'M', '123-456-7890', '123 Main St'),
 (2, 'Jane', 'Smith', '1992-08-21', 'F', '987-654-3210', '456 Oak St'),
 (3, 'Bob', 'Johnson', '1975-03-10', 'M', '555-123-4567', '789 Pine St');
-- Insert records into the Doctor table
INSERT INTO Doctor (DoctorID, FirstName, LastName, Specialty, ContactNumber, Email)
VALUES
 (1, 'Dr. Sarah', 'Williams', 'Cardiology', '111-222-3333', 'sarah@email.com'),
 (2, 'Dr. Michael', 'Jones', 'Pediatrics', '444-555-6666', 'michael@email.com'),
 (3, 'Dr. Emily', 'Smith', 'Orthopedics', '777-888-9999', 'emily@email.com');
-- Insert records into the Appointment table
INSERT INTO Appointment (AppointmentID, PatientID, DoctorID, AppointmentDate, 
AppointmentTime, Status)
VALUES
 (1, 1, 1, '2024-02-01', '10:00:00', 'Scheduled'),
 (2, 2, 2, '2024-02-03', '14:30:00', 'Completed'),
 (3, 3, 3, '2024-02-05', '09:15:00', 'Scheduled');
-- Insert records into the Department table
INSERT INTO Department (DepartmentID, DepartmentName, Description)
VALUES
 (1, 'Cardiology', 'Specializing in heart-related issues'),
 (2, 'Pediatrics', 'Medical care for children'),
 (3, 'Orthopedics', 'Dealing with musculoskeletal issues');
-- Insert records into the MedicalRecord table
INSERT INTO MedicalRecord (RecordID, PatientID, DoctorID, Diagnosis, Prescription, DateRecorded)
VALUES
 (1, 1, 1, 'High blood pressure', 'Medication A, Lifestyle changes', '2024-02-02'),
 (2, 2, 2, 'Common cold', 'Rest, plenty of fluids', '2024-02-04'),
 (3, 3, 3, 'Fractured leg', 'Surgery scheduled', '2024-02-06');